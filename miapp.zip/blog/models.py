from django.db import models

# Create your models here.

from django.db import models

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    image = models.ImageField(upload_to='blog_images/', blank=True, null=True)
    pdf_file = models.FileField(upload_to='blog_pdfs/', blank=True, null=True)
    video = models.URLField(blank=True, null=True)
    fecha_de_publicacion = models.DateTimeField(auto_now_add=True)
    autor = models.CharField(max_length=100, null=False)

    def __str__(self):
        return self.title